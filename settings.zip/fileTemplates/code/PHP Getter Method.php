#set($propertyName = $NAME.substring(0,1).toLowerCase().concat($NAME.substring(1)))


public ${STATIC} function $propertyName()#if(${RETURN_TYPE}): ${RETURN_TYPE}#else#end
{
#if (${STATIC} == "static")
    return self::$${FIELD_NAME};
#else
    return $this->${FIELD_NAME};
#end
}
