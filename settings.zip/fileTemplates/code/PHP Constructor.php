#set($parameters = $PARAM_LIST)
#set($parameters = $parameters.replace('$_', '$'))

#if ($parameters.split(',').size() > 3)
#set($parameters = '
' + $parameters.replace(',', ",
") + '
')
#end
public function __construct($parameters) {$BODY.replace('$_', '$')}